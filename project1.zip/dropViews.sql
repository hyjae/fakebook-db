DROP VIEW view_user_information;
DROP VIEW view_are_friends;
DROP VIEW view_photo_information;
DROP VIEW view_tag_information;
DROP VIEW view_event_information;